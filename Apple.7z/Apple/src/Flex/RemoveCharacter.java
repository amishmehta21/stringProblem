package Flex;

public class RemoveCharacter {

    public static void main(String[] args){
        String str = "AMISH MEHTA";
        char x = 'M';
        System.out.println(removeChr(str,x));
        System.out.println("using regex : " +removeusingRegex(str,x));
    }

    public static String removeChr(String str, char x){
        StringBuilder strBuilder = new StringBuilder();
        char[] rmString = str.toCharArray();
        for(int i=0; i<rmString.length; i++){
            if(rmString[i] == x){

            } else {
                strBuilder.append(rmString[i]);
            }
        }
        return strBuilder.toString();
    }
     
    public static String removeusingRegex(String str, char x){
    	
    	String s = str.replaceAll("["+x+" \\ss]", "");
    	return s;
    }
    
}

