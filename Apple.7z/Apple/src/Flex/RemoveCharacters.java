package Flex;

import java.util.HashMap;
import java.util.Scanner;

public class RemoveCharacters
{
    public static String removeCharsFromString(String word1, String word2)
    {
        StringBuilder sb = new StringBuilder(word1);

        System.out.println(sb);
        //char[] word2characters= word2.toCharArray();
        HashMap<Character, Integer> table = new HashMap<Character, Integer>();

        for (int i = 0; i < word2.length(); i++)
        {
            table.put(word2.charAt(i), 1);

        }

        int p = 0;
        for (int i = 0; i < word1.length(); i++)
        {

            if (table.containsKey(word1.charAt(i)))
            {
                if (p == 0)
                {
                    sb.deleteCharAt(i);
                    //p++;
                }
                else
                {
                    sb.deleteCharAt(i - p);
                }
                //System.out.println(sb);
                p++;
            }

        }

        return sb.toString();
    }
    
    public static String deleteAll(String originalword, String removecharacters) {
		return originalword.replaceAll(removecharacters, "");

	}

    public static void main(String[] args)
    {
        System.out.println("Enter your string");
        Scanner sc = new Scanner(System.in);
        String originalword = sc.nextLine();

        System.out.println("Enter the remove string");
        Scanner sc1 = new Scanner(System.in);
        String removecharacters = sc1.nextLine();

        String result = removeCharsFromString(originalword, removecharacters);
        
        String result2 = deleteAll(originalword, removecharacters);


        System.out.println("1st method:  "+result);
        
        System.out.println("2nd Method:  "+result2);
    }
}