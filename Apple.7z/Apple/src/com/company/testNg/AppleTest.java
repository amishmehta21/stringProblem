package com.company.testNg;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;

import org.testng.annotations.Test;

import Flex.RemoveCharacter;
import Flex.RemoveCharacters;

public class AppleTest extends RemoveCharacter {

	
	@Test
	   public void testdeleteAllPass() {
	      // assertEquals(String message, long expected, long actual)
	      assertEquals( "mish", RemoveCharacter.removeChr("amish", 'a'));
	      assertEquals( "amis", RemoveCharacter.removeChr("amish", 'h'));
	      assertEquals( "amsh", RemoveCharacter.removeChr("amish", 'i'));
	   
	   }
	 
	   @Test
	   public void testdeleteAllFail() {
	      // assertNotEquals(String message, long expected, long actual)
		   assertNotEquals( "mish", RemoveCharacter.removeChr("amish", 'A'));
		   assertNotEquals( "amsh", RemoveCharacter.removeChr("amish", 'I'));
		   assertNotEquals( "amsh", RemoveCharacter.removeChr("amish", 'e'));
		  

		   
	   }
	   
	   
	   @Test
	   public void testremoveCharsFromStringPass() {
	      // assertEquals(String message, long expected, long actual)
	      assertEquals( "meht", RemoveCharacter.removeusingRegex("mehta", 'a'));
	      assertEquals( "meta", RemoveCharacter.removeusingRegex("mehta", 'h'));
	      assertEquals( "ehta", RemoveCharacter.removeusingRegex("mehta", 'm'));
	   }
	 
	   @Test
	   public void testremoveCharsFromStringFail() {
	      // assertNotEquals(String message, long expected, long actual)
		   assertNotEquals( "meht", RemoveCharacter.removeusingRegex("mehta", 'A'));
		   assertNotEquals( "ehta", RemoveCharacter.removeusingRegex("mehta", 'M'));
		   assertNotEquals( "meht", RemoveCharacter.removeusingRegex("mehta", 's'));

		   
	   }
	   
	   
	 
}
