import static java.lang.System.*;

/*
 * This basic java example source code
 * shows how to delete all occurrences of a character on a String
 */

public class DeleteAllOccurrencesCharacter {

	public static void main(String[] args) {
		// Declare a string object
		String strValue = "aaxabbccddeefff";
		// call a method to delete all occurrences
		String newString = deleteAll(strValue, "a");
		// print the new string value
		out.println("New String:" + newString);

	}

	private static String deleteAll(String strValue, String charToRemove) {
		return strValue.replaceAll(charToRemove, "");

	}

}